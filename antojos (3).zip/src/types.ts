export type Category = 'Todo el Menú' | 'Tortas' | 'Sándwiches' | 'Antojitos' | 'Bebidas' | 'Frutas';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: Category;
  image: string;
  badge?: string;
}

export interface CartItem extends Product {
  quantity: number;
  notes?: string;
  selectedExtras?: string[];
}

export type Screen = 'menu' | 'categories' | 'cart' | 'detail' | 'voice' | 'location';
