import { useState, useMemo, useEffect, useRef } from 'react';
import { 
  Utensils, 
  LayoutDashboard, 
  Receipt, 
  User, 
  ShoppingCart, 
  Menu as MenuIcon, 
  Mic, 
  ChevronRight, 
  Plus, 
  Minus, 
  ArrowRight, 
  ArrowLeft,
  MapPin,
  HelpCircle,
  LogOut,
  Settings,
  CreditCard,
  History,
  Trash2,
  Send,
  Check,
  ShieldCheck,
  Leaf,
  Search,
  X,
  MessageSquare,
  AlertCircle,
  Volume2,
  VolumeX,
  Sparkles,
  Quote,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { products } from './data';
import { Product, CartItem, Screen, Category } from './types';
import { db } from './lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

const SHOP_INFO = {
  name: "Antojos",
  address: "Eduardo Gorostiza #3, Colonia La Purísima, C.P. 61650, Tacámbaro de Codallos, Michoacán",
  phone: "4591077967",
  whatsapp: "4591077967",
};

const MOTIVATIONAL_QUOTES = [
  "El ingrediente secreto siempre es el amor.",
  "Barriga llena, corazón contento.",
  "Hoy es un buen día para consentirte.",
  "La felicidad se cocina a fuego lento.",
  "Eres más fuerte de lo que crees y más capaz de lo que imaginas.",
  "A falta de amor, unos tacos al pastor (¡o una torta!)",
  "Tu sonrisa es el mejor postre.",
  "Haz de hoy una obra maestra culinaria.",
  "La mejor sazón es una mente positiva.",
  "Comer es una necesidad, pero disfrutar es un arte."
];

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('menu');
  const [selectedCategory, setSelectedCategory] = useState<Category>('Todo el Menú');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isMuted, setIsMuted] = useState(true);
  const [dailyQuote, setDailyQuote] = useState('');
  const [customerName, setCustomerName] = useState('');
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const savedName = localStorage.getItem('antojos_customer_name');
    if (savedName) setCustomerName(savedName);
  }, []);

  const handleFirestoreError = (error: any, operation: string, path: string) => {
    const errInfo = {
      error: error instanceof Error ? error.message : String(error),
      code: error.code,
      operation,
      path
    };
    console.error('Firestore Error Detailed:', JSON.stringify(errInfo));
    return errInfo;
  };

  useEffect(() => {
    setDailyQuote(MOTIVATIONAL_QUOTES[Math.floor(Math.random() * MOTIVATIONAL_QUOTES.length)]);
    
    // Recovery of last name used for convenience
    const savedName = localStorage.getItem('antojos_customer_name');
    if (savedName) {
      setCustomerName(savedName);
    }
  }, []);

  const toggleMusic = () => {
    if (!audioRef.current) return;
    if (isMuted) {
      audioRef.current.play().catch(e => console.log("Audio play failed", e));
      setIsMuted(false);
    } else {
      audioRef.current.pause();
      setIsMuted(true);
    }
  };

  const cartTotal = useMemo(() => cart.reduce((acc, item) => acc + (item.price * item.quantity), 0), [cart]);
  const cartCount = useMemo(() => cart.reduce((acc, item) => acc + item.quantity, 0), [cart]);

  const addToCart = (product: Product, quantity: number = 1, notes: string = '', extras: string[] = []) => {
    setCart(prev => {
      const existingItem = prev.find(item => item.id === product.id && item.notes === notes && JSON.stringify(item.selectedExtras) === JSON.stringify(extras));
      if (existingItem) {
        return prev.map(item => item === existingItem ? { ...item, quantity: item.quantity + quantity } : item);
      }
      return [...prev, { ...product, quantity, notes, selectedExtras: extras }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(0, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const navigateToDetail = (product: Product) => {
    setSelectedProduct(product);
    setCurrentScreen('detail');
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'menu': return (
        <MenuScreen 
          onProductClick={navigateToDetail} 
          selectedCategory={selectedCategory} 
          setSelectedCategory={setSelectedCategory} 
          setCurrentScreen={setCurrentScreen}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          dailyQuote={dailyQuote}
        />
      );
      case 'categories': return <CategoriesScreen onCategoryClick={(cat) => { setSelectedCategory(cat); setCurrentScreen('menu'); }} />;
      case 'cart': return (
        <CartScreen 
          cart={cart} 
          updateQuantity={updateQuantity} 
          removeFromCart={removeFromCart} 
          total={cartTotal} 
          onBack={() => setCurrentScreen('menu')} 
          setCart={setCart}
          customerName={customerName}
          setCustomerName={setCustomerName}
        />
      );
      case 'detail': return selectedProduct ? <DetailScreen product={selectedProduct} onAdd={addToCart} onBack={() => setCurrentScreen('menu')} /> : null;
      case 'voice': return <VoiceScreen onBack={() => setCurrentScreen('menu')} onProductSelect={navigateToDetail} />;
      case 'location': return <LocationScreen onBack={() => setCurrentScreen('menu')} />;
      default: return (
        <MenuScreen 
          onProductClick={navigateToDetail} 
          selectedCategory={selectedCategory} 
          setSelectedCategory={setSelectedCategory} 
          setCurrentScreen={setCurrentScreen}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          dailyQuote={dailyQuote}
        />
      );
    }
  };

  return (
    <div className="flex flex-col h-screen h-[100dvh] bg-surface-base max-w-md mx-auto relative overflow-hidden shadow-2xl">
      {/* Background Classical Music */}
      <audio 
        ref={audioRef}
        src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" 
        loop
        playsInline
        preload="auto"
        controls={false}
        onLoadedData={() => {
          if (audioRef.current) audioRef.current.volume = 0.3;
        }}
        onError={() => {
          // Avoid logging the event object directly to prevent circular structure errors
          console.error("Audio loading error, trying fallback");
          if (audioRef.current) {
            const fallbacks = [
              "https://upload.wikimedia.org/wikipedia/commons/e/ec/Mozart_-_Symphony_40_mvt_1.mp3",
              "https://upload.wikimedia.org/wikipedia/commons/d/d3/Beethoven_-_F%C3%BCr_Elise.mp3"
            ];
            const currentSrc = audioRef.current.src;
            const nextFallback = fallbacks.find(f => f !== currentSrc);
            if (nextFallback) {
              audioRef.current.src = nextFallback;
              audioRef.current.load();
            }
          }
        }}
      />

      {/* Music Toggle */}
      <div className="fixed bottom-24 left-6 z-50 flex flex-col items-center gap-2">
          {isMuted && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              key="music-tip"
              className="bg-primary text-white text-[12px] font-bold px-4 py-2 rounded-full whitespace-nowrap shadow-2xl animate-bounce border-2 border-white/30"
            >
              ¡Toca para música! 🎻
            </motion.div>
          )}
          <button 
            onClick={toggleMusic}
            aria-label="Toggle Music"
            className={`${isMuted ? 'bg-primary text-white' : 'bg-white/90 text-primary'} backdrop-blur-md p-5 rounded-full shadow-2xl border border-outline-variant/30 active:scale-95 transition-all hover:scale-105`}
          >
            {isMuted ? <VolumeX size={28} /> : <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 1.5 }}><Volume2 size={28} /></motion.div>}
          </button>
        </div>

      {/* Top App Bar */}
      {['menu', 'categories', 'cart', 'location'].includes(currentScreen) && (
        <header className="fixed top-0 w-full max-w-md z-40 bg-surface-lowest/90 backdrop-blur-md border-b border-outline-variant h-14 flex items-center justify-between px-6 px-safe-top">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setCurrentScreen('categories')}
              className="text-primary-container p-1 hover:bg-surface-low rounded-full transition-colors active:scale-95 duration-200"
            >
              <MenuIcon size={24} />
            </button>
            <h1 
              onClick={() => setCurrentScreen('menu')}
              className="text-xl font-bold text-primary-container tracking-tighter cursor-pointer"
            >
              {SHOP_INFO.name}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setCurrentScreen('voice')}
              className="text-on-surface-variant/70 hover:text-primary-container transition-colors flex flex-col items-center"
            >
              <MessageSquare size={22} />
              <span className="text-[8px] font-bold">Asistente</span>
            </button>
            <button 
              onClick={() => setCurrentScreen('cart')}
              className="relative p-1 text-on-surface-variant/70 hover:text-primary-container transition-colors active:scale-95 duration-200"
            >
              <ShoppingCart size={22} />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full font-bold shadow-sm">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </header>
      )}

      {/* Main Content */}
      <main className={`flex-1 overflow-y-auto ${['menu', 'categories', 'cart', 'location'].includes(currentScreen) ? 'pt-14 pb-20' : ''}`}>
        <AnimatePresence mode="wait">
          <motion.div
            key={currentScreen}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
            className="h-full"
          >
            {renderScreen()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Nav Bar */}
      {['menu', 'categories', 'cart', 'location'].includes(currentScreen) && (
        <nav className="fixed bottom-0 w-full max-w-md z-40 bg-surface-lowest/90 backdrop-blur-md border-t border-outline-variant py-2 flex justify-around items-center px-4 pb-safe-bottom">
          <NavItem 
            active={currentScreen === 'menu' || currentScreen === 'voice'} 
            onClick={() => setCurrentScreen('menu')} 
            icon={<Utensils size={20} />} 
            label="Menú" 
          />
          <NavItem 
            active={currentScreen === 'categories'} 
            onClick={() => setCurrentScreen('categories')} 
            icon={<LayoutDashboard size={20} />} 
            label="Categorías" 
          />
          <NavItem 
            active={currentScreen === 'cart'} 
            onClick={() => setCurrentScreen('cart')} 
            icon={<Receipt size={20} />} 
            label="Pedidos" 
          />
          <NavItem 
            active={currentScreen === 'location'} 
            onClick={() => setCurrentScreen('location')} 
            icon={<MapPin size={20} />} 
            label="Ubicación" 
          />
        </nav>
      )}

      {/* Floating Action Button (Cart) */}
      {currentScreen === 'menu' && cartCount > 0 && (
        <motion.button
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          onClick={() => setCurrentScreen('cart')}
          className="fixed bottom-24 right-6 left-6 z-30 bg-primary-container text-white px-6 py-4 rounded-full shadow-lg shadow-primary-container/30 flex items-center justify-between active:scale-95 transition-transform"
        >
          <div className="flex items-center gap-3">
            <ShoppingCart size={20} />
            <span className="font-bold">Ver Carrito</span>
          </div>
          <span className="bg-white/20 px-3 py-1 rounded-full text-sm font-bold">
            ${cartTotal}
          </span>
        </motion.button>
      )}
    </div>
  );
}

function NavItem({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all duration-200 active:scale-90 ${active ? 'text-primary' : 'text-on-surface-variant/50'}`}
    >
      <div className={`${active ? 'bg-primary/5 p-1 px-3 rounded-full' : ''}`}>
        {icon}
      </div>
      <span className="text-[10px] font-bold uppercase tracking-wider mt-1 font-label">{label}</span>
    </button>
  );
}

// --- Screens Components ---

function OnboardingScreen() {
  return null;
}

function MenuScreen({ onProductClick, selectedCategory, setSelectedCategory, setCurrentScreen, searchQuery, setSearchQuery, dailyQuote }: { 
  onProductClick: (p: Product) => void, 
  selectedCategory: Category, 
  setSelectedCategory: (c: Category) => void,
  setCurrentScreen: (s: Screen) => void,
  searchQuery: string,
  setSearchQuery: (q: string) => void,
  dailyQuote: string
}) {
  const categories: Category[] = ['Todo el Menú', 'Tortas', 'Sándwiches', 'Antojitos', 'Bebidas', 'Frutas'];
  
  const filteredProducts = useMemo(() => {
    let result = products;
    if (selectedCategory !== 'Todo el Menú') {
      result = result.filter(p => p.category === selectedCategory);
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(p => 
        p.name.toLowerCase().includes(q) || 
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
      );
    }
    return result;
  }, [selectedCategory, searchQuery]);

  return (
    <div className="px-container-margin py-6">
      {/* Motivational Quote */}
      <AnimatePresence mode="wait">
        {!searchQuery && selectedCategory === 'Todo el Menú' && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 p-4 bg-primary/5 rounded-3xl border border-primary/10 flex items-center gap-4 relative overflow-hidden group"
          >
            <div className="absolute -right-4 -top-4 opacity-5 group-hover:opacity-10 transition-opacity">
              <Quote size={80} className="text-primary rotate-12" />
            </div>
            <div className="bg-primary/10 p-3 rounded-2xl flex-shrink-0">
               <Sparkles size={20} className="text-primary" />
            </div>
            <p className="text-sm italic font-medium text-on-surface-variant leading-snug">
               "{dailyQuote}"
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Search Bar */}
      <div className="mb-6 relative">
        <div className="relative group">
          <input
            type="text"
            placeholder="Buscar por antojo o ingrediente..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-surface-lowest border border-outline-variant p-4 pl-12 rounded-[24px] focus:outline-none focus:border-primary-container transition-all shadow-sm group-hover:shadow-md"
          />
          <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant/40" />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-on-surface-variant/40 hover:text-primary-container transition-colors p-1"
            >
              <X size={18} />
            </button>
          )}
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-4">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-bold border transition-all duration-200 ${
              selectedCategory === cat 
                ? 'bg-primary-container border-primary-container text-white shadow-md' 
                : 'bg-surface-lowest border-outline-variant text-on-surface-variant hover:bg-surface-low'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="space-y-8 mt-4">
        <section>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-on-surface leading-tight">
              {searchQuery ? 'Resultados de búsqueda' : (selectedCategory === 'Todo el Menú' ? 'Clásicos Favoritos' : selectedCategory)}
            </h3>
            {!searchQuery && selectedCategory === 'Todo el Menú' && (
              <span className="bg-secondary-container/20 text-on-secondary-container text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider">
                Recomendados
              </span>
            )}
          </div>

          <div className="mb-6">
            <button 
              onClick={() => setCurrentScreen('voice')}
              className="w-full bg-surface-low border border-outline-variant p-4 rounded-2xl flex items-center justify-between group active:scale-[0.98] transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="bg-primary-container text-white p-2 rounded-full shadow-sm">
                  <Mic size={18} />
                </div>
                <div className="text-left">
                  <p className="text-sm font-bold text-on-surface">Pide con tu voz</p>
                  <p className="text-[11px] text-on-surface-variant opacity-70">"Quiero una torta de milanesa..."</p>
                </div>
              </div>
              <ArrowRight size={18} className="text-on-surface-variant/30 group-hover:text-primary transition-colors" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {filteredProducts.map(product => (
              <motion.div 
                key={product.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onProductClick(product)}
                className="bg-surface-lowest rounded-2xl border border-outline-variant overflow-hidden group flex flex-col hover:shadow-md transition-all duration-300"
              >
                <div className="h-40 overflow-hidden relative">
                  <motion.img 
                    layoutId={`product-image-${product.id}`}
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
                  />
                  {product.badge && (
                    <span className="absolute top-2 left-2 bg-secondary text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm">
                      {product.badge}
                    </span>
                  )}
                </div>
                <div className="p-4 flex flex-col justify-between flex-1">
                  <motion.h4 layoutId={`product-title-${product.id}`} className="font-bold text-on-surface line-clamp-1">{product.name}</motion.h4>
                  <div className="flex items-center justify-between mt-2">
                    <motion.span layoutId={`product-price-${product.id}`} className="text-primary font-bold text-lg">${product.price}</motion.span>
                    <button 
                        onClick={(e) => {
                            e.stopPropagation();
                            onProductClick(product);
                        }}
                        className="text-white bg-secondary hover:bg-secondary/90 p-1.5 rounded-xl shadow-sm transition-colors active:scale-90"
                    >
                      <Plus size={18} />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="py-20 text-center opacity-40">
              <Search size={48} className="mx-auto mb-4" />
              <p className="font-bold">No encontramos nada</p>
              <p className="text-sm">Intenta con otra búsqueda</p>
              <button onClick={() => setSearchQuery('')} className="mt-4 text-primary font-bold">Limpiar búsqueda</button>
            </div>
          )}
        </section>
      </div>

      <div className="mt-12 mb-20 text-center">
        <div className="inline-flex items-center gap-2 p-3 bg-surface-low rounded-2xl border border-outline-variant text-on-surface-variant/70 text-sm italic">
          <Leaf size={16} className="text-secondary" />
          Gastronomía honesta para tu día a día
        </div>
      </div>
    </div>
  );
}

function CategoriesScreen({ onCategoryClick }: { onCategoryClick: (cat: Category) => void }) {
  const cats: { name: Category, image: string, span?: boolean }[] = [
    { name: 'Tortas', image: products[0].image, span: true },
    { name: 'Antojitos', image: products[3].image },
    { name: 'Frutas', image: products[4].image },
    { name: 'Sándwiches', image: products[1].image },
    { name: 'Bebidas', image: products[8].image },
  ];

  return (
    <div className="px-container-margin py-8">
      <header className="mb-8">
        <h2 className="text-3xl font-bold text-on-surface mb-2 leading-tight">Explora el sabor</h2>
        <p className="text-on-surface-variant">Selecciona una categoría para ver los ingredientes más frescos del día.</p>
      </header>

      <div className="grid grid-cols-2 gap-4">
        {cats.map((cat, i) => (
          <motion.div
            key={cat.name}
            whileTap={{ scale: 0.98 }}
            onClick={() => onCategoryClick(cat.name)}
            className={`relative rounded-2xl overflow-hidden border border-outline-variant shadow-sm group ${cat.span ? 'col-span-2 aspect-[16/9]' : 'aspect-square'}`}
          >
            <img src={cat.image} alt={cat.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
            <div className={`absolute bottom-0 left-0 w-full p-4 flex justify-between items-end ${!cat.span ? 'flex-col items-start gap-1 p-3' : ''}`}>
              <h3 className={`text-white font-bold ${cat.span ? 'text-2xl' : 'text-lg'}`}>
                {cat.name}
              </h3>
              <div className="bg-white/20 p-1.5 rounded-full backdrop-blur-sm group-hover:bg-white group-hover:text-primary transition-all duration-200">
                <ChevronRight size={cat.span ? 20 : 16} className="text-white group-hover:text-primary" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function CartScreen({ cart, updateQuantity, removeFromCart, total, onBack, setCart, customerName, setCustomerName }: { 
  cart: CartItem[], 
  updateQuantity: (id: string, delta: number) => void, 
  removeFromCart: (id: string) => void,
  total: number,
  onBack: () => void,
  setCart: (c: CartItem[]) => void,
  customerName: string,
  setCustomerName: (n: string) => void
}) {
  const [isSaving, setIsSaving] = useState(false);

  const confirmOrder = async () => {
    if (!customerName.trim()) {
      alert("Por favor ingresa tu nombre para el pedido.");
      return;
    }

    setIsSaving(true);
    try {
      // Save name for convenience
      localStorage.setItem('antojos_customer_name', customerName);

      // 1. Save to Firebase
      const saleDoc = await addDoc(collection(db, 'sales'), {
        items: cart.map(i => ({
          name: i.name,
          price: i.price,
          quantity: i.quantity,
          notes: i.notes || '',
          extras: i.selectedExtras || []
        })),
        total,
        customerName: customerName,
        customerPhone: 'Vía WhatsApp',
        status: 'pending',
        createdAt: serverTimestamp()
      });

      // 2. Open WhatsApp with Order ID
      const orderId = saleDoc.id.slice(-6).toUpperCase();
      const message = `Hola Wera, soy ${customerName}. Quiero pasar a recoger mi pedido (ID: ${orderId}) por un total de $${total} MXN. Contiene: ${cart.map(i => `${i.quantity}x ${i.name}`).join(', ')}. Pago en efectivo al llegar.`;
      
      window.open(`https://wa.me/${SHOP_INFO.whatsapp}?text=${encodeURIComponent(message)}`, '_blank');
      
    } catch (error: any) {
      console.error("Error saving sale:", error);
      alert("Hubo un error al guardar tu pedido. Por favor intenta de nuevo.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-full flex flex-col bg-surface-base px-container-margin py-6 pb-32">
      <div className="mb-8 p-1">
        <h2 className="text-3xl font-bold text-on-surface mb-1 leading-tight">Tu Carrito</h2>
        <p className="text-on-surface-variant">Revisa tus antojos antes de enviar el pedido a cocina.</p>
      </div>

      {cart.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center opacity-40 py-20">
          <ShoppingCart size={64} className="mb-4" />
          <p className="text-xl font-bold">Carrito vacío</p>
          <p>Explora el menú y agrega tus favoritos</p>
          <button onClick={onBack} className="mt-6 text-primary font-bold flex items-center gap-2">
            Ver menú <ArrowRight size={20} />
          </button>
        </div>
      ) : (
        <div className="space-y-4 mb-8">
          {cart.map(item => (
            <div key={item.id} className="bg-surface-lowest p-4 rounded-2xl border border-outline-variant/30 flex gap-4 shadow-sm">
              <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0 bg-surface-low p-2">
                <img src={item.image} alt={item.name} className="w-full h-full object-contain" />
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <h4 className="font-bold text-on-surface">{item.name}</h4>
                  <span className="text-primary font-bold">${item.price * item.quantity}</span>
                </div>
                {item.notes && <p className="text-xs text-secondary mt-1 flex items-center gap-1 italic"><Receipt size={12} /> {item.notes}</p>}
                
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center gap-3">
                    <button onClick={() => updateQuantity(item.id, -1)} className="w-8 h-8 rounded-full border border-outline-variant flex items-center justify-center active:bg-surface-low transition-all"><Minus size={14} /></button>
                    <span className="font-bold w-4 text-center">{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.id, 1)} className="w-8 h-8 rounded-full border border-primary text-primary flex items-center justify-center active:bg-primary-fixed transition-all"><Plus size={14} /></button>
                  </div>
                  <button onClick={() => removeFromCart(item.id)} className="text-error/50 hover:text-error transition-colors"><Trash2 size={18} /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {cart.length > 0 && (
        <>
          <div className="bg-surface-low p-6 rounded-3xl border border-outline-variant mb-8 space-y-6">
            <div>
              <label className="text-xs font-bold text-primary uppercase tracking-widest block mb-2 px-1">¿A nombre de quién?</label>
              <input 
                type="text" 
                placeholder="Tu nombre para el pedido" 
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full bg-surface-lowest border border-outline-variant/50 px-4 py-3 rounded-xl focus:outline-none focus:border-primary transition-colors font-medium text-sm"
              />
            </div>
            
            <div className="space-y-2 border-t border-outline-variant/30 pt-4">
              <div className="flex justify-between text-on-surface-variant font-medium text-sm"><span>Subtotal</span><span>${total}</span></div>
              <div className="flex justify-between items-center"><span className="text-on-surface-variant font-medium text-sm">Método</span><span className="bg-secondary-container/30 text-on-secondary-container text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">Recoger en Tienda</span></div>
            </div>
            <div className="pt-4 border-t border-outline-variant/50 flex justify-between items-baseline">
              <span className="text-xl font-bold">Total</span>
              <span className="text-2xl font-bold text-primary">${total} MXN</span>
            </div>
          </div>

          <div className="mb-8 p-1">
            <p className="text-[10px] text-on-surface-variant/40 mb-2 uppercase font-bold tracking-widest text-center">
              Mensaje a enviar a WhatsApp:
            </p>
            <div className="bg-surface-lowest p-5 rounded-2xl border border-outline-variant relative ml-2 shadow-sm italic text-on-surface/80 text-xs">
              <div className="absolute top-4 -left-2 w-4 h-4 bg-surface-lowest border-l border-b border-outline-variant rotate-45" />
              Hola Wera, soy {customerName || '...'} . Quiero pasar a recoger {cart.map(i => `${i.quantity}x ${i.name}`).join(', ')} por un total de ${total} MXN. Pago en efectivo al llegar.
            </div>
          </div>

          <button 
            onClick={confirmOrder}
            disabled={isSaving}
            className="w-full bg-secondary text-white py-4 rounded-2xl font-bold text-lg shadow-lg shadow-secondary/20 flex items-center justify-center gap-3 active:scale-95 transition-transform duration-200 disabled:opacity-50 disabled:scale-100"
          >
            {isSaving ? <Loader2 className="animate-spin" /> : <Send size={20} />}
            {isSaving ? 'Guardando pedido...' : 'Confirmar y Enviar WhatsApp'}
          </button>
        </>
      )}
    </div>
  );
}

function DetailScreen({ product, onAdd, onBack }: { product: Product, onAdd: (p: Product, q: number, n: string, ex: string[]) => void, onBack: () => void }) {
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState('');
  const [selectedExtras, setSelectedExtras] = useState<string[]>([]);

  const extras = (product.category === 'Tortas' || product.category === 'Sándwiches') ? [
    { name: 'Milanesa' },
    { name: 'Arrachera' },
    { name: 'Salchicha' },
    { name: 'Jamón' },
    { name: 'Asadero' },
    { name: 'Pollo Asado' }
  ] : [];

  const totalPrice = useMemo(() => {
    const isCombo = selectedExtras.length >= 2;
    const additionalCost = isCombo ? 10 : 0;
    // Base price is 40 for Tortas/Sandwiches. 
    // If it's a different product, we just use its base price.
    return product.price + additionalCost;
  }, [product.price, selectedExtras]);

  const toggleExtra = (extraName: string) => {
    setSelectedExtras(prev => prev.includes(extraName) ? prev.filter(e => e !== extraName) : [...prev, extraName]);
  };

  const handleAdd = () => {
    const updatedProduct = { ...product, price: totalPrice };
    onAdd(updatedProduct, quantity, notes, selectedExtras);
    onBack();
  };

  return (
    <div className="min-h-full bg-surface-base flex flex-col pb-32">
      <header className="fixed top-0 w-full max-w-md z-40 bg-transparent flex items-center justify-between px-6 h-16">
        <button onClick={onBack} className="bg-surface-lowest/80 backdrop-blur-md p-2 rounded-full shadow-md active:scale-95 text-primary transition-transform duration-200">
          <ArrowLeft size={24} />
        </button>
        <div className="flex gap-4">
          <button className="bg-surface-lowest/80 backdrop-blur-md p-2 rounded-full shadow-md active:scale-95 text-primary transition-transform duration-200">
            <HelpCircle size={24} />
          </button>
        </div>
      </header>

      <div className="h-72 relative overflow-hidden">
        <motion.img 
          layoutId={`product-image-${product.id}`}
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover" 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
      </div>

      <div className="flex-1 bg-surface-base -mt-8 rounded-t-[32px] p-container-margin relative z-10 border-t border-outline-variant shadow-xl flex flex-col">
        <div className="flex justify-between items-start mb-2">
          <div className="flex-1">
            <motion.h2 layoutId={`product-title-${product.id}`} className="text-3xl font-bold text-on-surface tracking-tighter mb-2 leading-tight">{product.name}</motion.h2>
            <div className="flex gap-2">
              <span className="bg-secondary-container/20 text-on-secondary-container text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider font-label">
                Receta original
              </span>
              <span className="bg-primary/5 text-primary text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider font-label">
                {product.category}
              </span>
            </div>
          </div>
          <motion.p layoutId={`product-price-${product.id}`} className="text-3xl font-bold text-primary tracking-tight">${totalPrice}</motion.p>
        </div>
        
        <p className="text-on-surface-variant leading-relaxed mt-6 text-lg">{product.description}</p>

        <div className="h-px bg-outline-variant/30 mt-10 mb-8" />

        <div className="space-y-8 flex-1">
          {extras.length > 0 && (
            <div>
              <h4 className="text-lg font-bold mb-4 flex items-center gap-2">
                <Plus size={20} className="text-primary-container" />
                ¿Deseas algo extra?
              </h4>
              <div className="space-y-3">
                {extras.map(ex => (
                  <button 
                    key={ex.name} 
                    onClick={() => toggleExtra(ex.name)}
                    className={`w-full p-4 rounded-2xl border flex items-center justify-between transition-all duration-200 ${
                      selectedExtras.includes(ex.name) ? 'bg-primary/5 border-primary shadow-sm' : 'bg-surface-lowest border-outline-variant/30'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all duration-200 ${selectedExtras.includes(ex.name) ? 'bg-primary border-primary' : 'border-outline-variant'}`}>
                        {selectedExtras.includes(ex.name) && <Check size={12} className="text-white" />}
                      </div>
                      <span className="font-bold text-on-surface">{ex.name}</span>
                    </div>
                  </button>
                ))}
              </div>
              <p className="text-xs text-primary font-bold italic mt-4 opacity-80">
                * Elige 1 ingrediente por $40 o combina 2 o más por solo $50.
              </p>
            </div>
          )}

          <div>
            <label className="text-lg font-bold mb-3 block flex items-center gap-2">
              <Receipt size={20} className="text-primary-container" />
              Notas especiales
            </label>
            <textarea 
              placeholder="Ej: sin cebolla, con extra picante..." 
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-surface-lowest p-5 rounded-2xl border border-outline-variant/50 focus:outline-none focus:border-primary-container transition-all resize-none h-32 shadow-sm"
            />
          </div>
        </div>

        <div className="fixed bottom-0 left-0 w-full max-w-md p-6 bg-surface-lowest/90 backdrop-blur-md border-t border-outline-variant flex items-center gap-4 z-50">
          <div className="flex items-center bg-surface-low border border-outline-variant rounded-full px-2 py-1 shadow-inner">
            <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="w-10 h-10 flex items-center justify-center text-primary-container active:scale-75 transition-all"><Minus size={18} /></button>
            <span className="w-8 text-center font-bold text-lg text-on-surface">{quantity}</span>
            <button onClick={() => setQuantity(q => q + 1)} className="w-10 h-10 flex items-center justify-center text-primary-container active:scale-75 transition-all"><Plus size={18} /></button>
          </div>
          <button 
            onClick={handleAdd}
            className="flex-1 bg-primary text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-3 shadow-lg shadow-primary/20 active:scale-[0.98] transition-all duration-200"
          >
            Agregar al Carrito • ${totalPrice * quantity}
            <ShoppingCart size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}

function VoiceScreen({ onBack, onProductSelect }: { onBack: () => void, onProductSelect: (p: Product) => void }) {
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant', content: string }[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  const speak = (text: string) => {
    if (!window.speechSynthesis) return;
    
    // Explicitly handle voice loading which can be async
    const performSpeech = () => {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'es-MX';
      utterance.rate = 1.1; 
      utterance.pitch = 1.0;
      
      const voices = window.speechSynthesis.getVoices();
      const voice = voices.find(v => v.lang.startsWith('es-MX')) || 
                    voices.find(v => v.lang.startsWith('es')) ||
                    voices[0];
      
      if (voice) utterance.voice = voice;
      window.speechSynthesis.speak(utterance);
    };

    if (window.speechSynthesis.getVoices().length === 0) {
      const loadHandler = () => {
        performSpeech();
        window.speechSynthesis.removeEventListener('voiceschanged', loadHandler);
      };
      window.speechSynthesis.addEventListener('voiceschanged', loadHandler);
    } else {
      performSpeech();
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  useEffect(() => {
    // Initialize Speech Recognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'es-MX';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        handleSendMessage(transcript);
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const toggleListening = () => {
    if (!recognitionRef.current) {
      alert("Lo siento, tu navegador no soporta reconocimiento de voz.");
      return;
    }

    if (isListening) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        console.error("Stop recognition error:", e);
      }
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (e: any) {
        if (e && e.message && e.message.includes('already started')) {
          console.log("Recognition already active, syncing state.");
          setIsListening(true);
        } else {
          console.error("Start recognition error:", e);
          setIsListening(false);
        }
      }
    }
  };

  const handleSendMessage = async (userText: string) => {
    if (!userText.trim() || isTyping) return;

    // Ensure listening is stopped if sending manually
    if (isListening && recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
      setIsListening(false);
    }

    setMessages(prev => [...prev, { role: 'user', content: userText }]);
    setIsTyping(true);
    setInputValue(''); // Clear input

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages, userText }),
      });
      
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Error en el servidor");

      const aiText = data.text || "No pude procesar eso. ¿Otra pregunta?";
      setMessages(prev => [...prev, { role: 'assistant', content: aiText }]);
      
      try {
        if (typeof window !== 'undefined' && window.speechSynthesis) {
          speak(aiText);
        }
      } catch (speechErr) {
        console.error("Speech error:", speechErr instanceof Error ? speechErr.message : "unknown");
      }

      // Check if user mentioned a specific product to "auto-navigate"
      const mentionedProduct = products.find(p => 
        userText.toLowerCase().includes(p.name.toLowerCase()) || 
        aiText.toLowerCase().includes(p.name.toLowerCase())
      );
      if (mentionedProduct && (userText.toLowerCase().includes('quiero') || userText.toLowerCase().includes('pide'))) {
        setTimeout(() => onProductSelect(mentionedProduct), 2000);
      }

    } catch (error) {
      console.error("Gemini Error:", error instanceof Error ? error.message : "unknown");
      const errorMessage = error instanceof Error && error.message.includes("404") 
        ? "El asistente está en mantenimiento. Por favor intenta de nuevo en un momento." 
        : "Hubo un error de conexión con el asistente. ¿Podrías repetirlo?";
      setMessages(prev => [...prev, { role: 'assistant', content: errorMessage }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-surface-base relative">
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-primary/5 pointer-events-none" />
      
      <header className="fixed top-0 w-full max-w-md z-50 bg-surface-lowest/80 backdrop-blur-xl border-b border-outline-variant/30 h-14 flex items-center justify-between px-6">
        <button onClick={onBack} className="text-on-surface-variant/70 p-2 hover:bg-surface-low rounded-full transition-colors">
          <ArrowLeft size={22} />
        </button>
        <div className="flex flex-col items-center">
            <span className="font-bold text-primary-container leading-none">Asistente Virtual</span>
            <span className="text-[10px] text-secondary font-bold uppercase tracking-widest mt-1 opacity-70">En línea</span>
        </div>
        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <Sparkles size={18} className="text-primary" />
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-6 py-20 space-y-6 pt-20 scrollbar-hide" ref={scrollRef}>
        {messages.length === 0 && (
          <div className="text-center py-10 flex flex-col items-center">
            <motion.div 
              animate={isListening ? { 
                scale: [1, 1.25, 1],
                boxShadow: ["0 0 0px rgba(172, 53, 9, 0)", "0 0 60px rgba(172, 53, 9, 0.4)", "0 0 0px rgba(172, 53, 9, 0)"]
              } : { 
                scale: [1, 1.05, 1],
                boxShadow: ["0 0 0px rgba(172, 53, 9, 0)", "0 0 40px rgba(172, 53, 9, 0.1)", "0 0 0px rgba(172, 53, 9, 0)"]
              }}
              transition={{ repeat: Infinity, duration: isListening ? 1.5 : 3 }}
              onClick={toggleListening}
              className={`w-28 h-28 rounded-full flex items-center justify-center mb-8 shadow-2xl relative cursor-pointer ${
                isListening ? 'bg-secondary text-white' : 'bg-primary-container text-white'
              }`}
            >
              <Mic size={56} className="relative z-10" />
              {isListening && (
                <div className="absolute inset-0 rounded-full bg-secondary animate-ping opacity-30" />
              )}
            </motion.div>
            
            <h3 className="text-3xl font-bold mb-3 tracking-tight">
              {isListening ? 'Te escucho...' : 'Estamos para escucharte'}
            </h3>
            <p className="text-on-surface-variant font-medium leading-relaxed mb-10 px-6 opacity-80">
                {isListening ? 'Dime lo que se te antoja.' : 'Presiona el micrófono para pedir con tu voz o consulta la ubicación.'}
            </p>
            
            <div className="grid grid-cols-1 gap-3 w-full max-w-[280px]">
              {[
                { text: '¿Cuál es la dirección?', icon: <MapPin size={16} /> },
                { text: 'Quiero una torta de milanesa', icon: <Utensils size={16} /> },
                { text: '¿Qué bebidas tienen?', icon: <Receipt size={16} /> },
                { text: 'Dime el teléfono', icon: <User size={16} /> }
              ].map(item => (
                <button 
                  key={item.text}
                  onClick={() => handleSendMessage(item.text)}
                  className="bg-white border border-outline-variant/50 p-4 rounded-3xl text-left font-bold text-sm hover:border-primary/40 hover:bg-primary/5 transition-all active:scale-[0.98] flex items-center justify-between group shadow-sm"
                >
                  <span className="text-on-surface-variant group-hover:text-primary transition-colors">{item.text}</span>
                  <div className="text-on-surface-variant/20 group-hover:text-primary/40 transition-colors">{item.icon}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20, scale: 0.9, originX: m.role === 'user' ? 1 : 0 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`max-w-[85%] p-5 rounded-[28px] shadow-sm relative ${
              m.role === 'user' 
                ? 'bg-primary-container text-white rounded-tr-none shadow-primary-container/20' 
                : 'bg-white border border-outline-variant/60 text-on-surface rounded-tl-none font-medium'
            }`}>
              {m.role === 'assistant' && (
                <div className="absolute -top-6 left-2 flex items-center gap-2">
                   <div className="w-5 h-5 rounded-full bg-primary-container flex items-center justify-center">
                      <Sparkles size={10} className="text-white" />
                   </div>
                   <span className="text-[10px] font-bold text-primary tracking-widest uppercase">La Wera</span>
                </div>
              )}
              <p className="text-sm leading-relaxed">{m.content}</p>
            </div>
          </motion.div>
        ))}

        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white border border-outline-variant/60 p-4 rounded-[28px] rounded-tl-none shadow-sm flex gap-1">
              <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1 }} className="w-2 h-2 bg-on-surface-variant/20 rounded-full" />
              <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-2 h-2 bg-on-surface-variant/20 rounded-full" />
              <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-2 h-2 bg-on-surface-variant/20 rounded-full" />
            </div>
          </div>
        )}
      </div>

      <div className="p-6 pb-24 bg-surface-lowest/80 backdrop-blur-xl border-t border-outline-variant/30">
        <div className="relative group">
          <input 
            type="text" 
            placeholder="Conversa con el restaurante..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => {
                if (e.key === 'Enter') {
                    handleSendMessage(inputValue);
                }
            }}
            className="w-full bg-surface-low/50 border border-outline-variant p-5 pr-28 rounded-[24px] focus:outline-none focus:border-primary-container focus:bg-white transition-all shadow-inner font-medium text-sm"
          />
          <div className="absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center gap-2">
            <button 
              onClick={toggleListening}
              className={`p-3 rounded-2xl transition-all active:scale-90 ${
                isListening ? 'bg-secondary text-white animate-pulse' : 'bg-surface-lowest text-on-surface-variant border border-outline-variant'
              }`}
            >
              <Mic size={20} />
            </button>
            <button 
              className="bg-primary-container text-white p-3 rounded-2xl shadow-lg shadow-primary-container/20 active:scale-90 transition-all hover:brightness-110"
              onClick={() => handleSendMessage(inputValue)}
            >
              <Send size={20} />
            </button>
          </div>
        </div>
        <p className="text-[10px] text-center mt-4 text-on-surface-variant font-bold uppercase tracking-widest opacity-40">Impulsado por AI Studio</p>
      </div>
    </div>
  );
}

function LocationScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="min-h-full flex flex-col bg-surface-base overflow-y-auto pb-32">
       <header className="fixed top-0 w-full max-w-md z-50 bg-surface-lowest/90 backdrop-blur-md border-b border-outline-variant h-14 flex items-center px-6">
          <button onClick={onBack} className="text-on-surface-variant/70 p-1">
            <ArrowLeft size={24} />
          </button>
          <span className="ml-4 font-bold text-primary-container">Ubicación y Contacto</span>
       </header>

       <div className="h-[350px] mt-14 bg-stone-100 flex flex-col items-center justify-center relative overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?q=80&w=2666&auto=format&fit=crop" 
            alt="Map" 
            className="w-full h-full object-cover"
          />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
             <MapPin size={56} className="text-primary-container fill-primary-container/20 drop-shadow-2xl animate-bounce" />
          </div>
          <button 
            onClick={() => window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(SHOP_INFO.address)}`, '_blank')}
            className="absolute bottom-6 right-6 left-6 bg-primary text-white p-4 rounded-2xl shadow-2xl font-bold text-base flex items-center justify-center gap-3 active:scale-95 transition-transform duration-200"
          >
            <ArrowRight size={22} /> Abrir en Google Maps
          </button>
       </div>

       <div className="px-container-margin py-8 flex flex-col gap-8">
          <div className="bg-surface-lowest p-6 rounded-[32px] border border-outline-variant shadow-sm flex items-start gap-4">
             <div className="bg-primary/5 p-3 rounded-2xl text-primary border border-primary/10 flex-shrink-0">
                <MapPin size={24} />
             </div>
             <div>
                <h3 className="text-lg font-bold mb-1">Pasa por tu pedido</h3>
                <p className="text-on-surface-variant text-sm leading-relaxed font-medium">
                   {SHOP_INFO.address}. <br/>
                   <span className="text-primary font-bold">Nota: Solo entrega física en local. No contamos con servicio a domicilio.</span>
                </p>
             </div>
          </div>

          <div className="bg-surface-lowest p-6 rounded-[32px] border border-outline-variant shadow-sm flex items-start gap-4">
             <div className="bg-blue-500/5 p-3 rounded-2xl text-blue-500 border border-blue-500/10 flex-shrink-0">
                <HelpCircle size={24} />
             </div>
             <div className="flex-1">
                <h3 className="text-lg font-bold mb-1">Contacto</h3>
                <p className="text-xs text-on-surface-variant mb-4 font-medium italic opacity-70">¿Dudas o pedidos? Estamos para servirte. Recuerda que solo recolectamos en tienda.</p>
                <div className="space-y-3">
                   <a href={`tel:${SHOP_INFO.phone}`} className="flex items-center justify-between p-3 bg-surface-low rounded-xl border border-outline-variant/30 active:scale-95 transition-all">
                     <span className="font-bold text-sm">{SHOP_INFO.phone}</span>
                     <ArrowRight size={16} className="text-primary" />
                   </a>
                   <a 
                    href={`https://wa.me/${SHOP_INFO.whatsapp}`} 
                    target="_blank"
                    className="flex items-center justify-between p-3 bg-secondary/5 text-secondary rounded-xl border border-secondary/10 active:scale-95 transition-all"
                   >
                     <span className="font-bold text-sm">WhatsApp Directo</span>
                     <ArrowRight size={16} />
                   </a>
                </div>
             </div>
          </div>
       </div>
    </div>
  );
}
