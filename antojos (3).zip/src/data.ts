import { Product } from './types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Tortas',
    description: 'Tradicional torta mexicana. Elige tu ingrediente favorito o combínalos.',
    price: 40,
    category: 'Tortas',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBhZovs5bZ7TQdfry3sTh365cY5PMQTvjxb5ThQ9Qb79EL7nw0QGkdBcPOgw9jwx2_ZGDB_IF3a0UxSwNBNpLyohRwgwNSmw9E7t7yQZH9id2gN81cduxIxtvijl57XjyFD9kDllnEffbjGoj3rbk1RxFeQK8aOd3TpkCqEmmKxhe_Wmqk2zzt1f7Xo42Bv2R0_h_b4YtmhbX9J_7QdRfR00p_fIRrrn6E02Qhh1l1KF53jYUCv5n5M7VLYZO95dZuQRUQPRnEtF1Q',
    badge: 'Popular'
  },
  {
    id: '2',
    name: 'Sándwiches',
    description: 'Sándwich delicioso. Elige tu ingrediente favorito o combínalos.',
    price: 40,
    category: 'Sándwiches',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuASlF8U6Kyv2K1c6Vajx3RzmzZNsm9T9WvoVBXtHGJPRFUdNBXUAWIq2oeqilgP09Ly0uR-t98T8qPz5Ut5CAWSU6D5qIobOdqh6VysR-C8574mwKAaaVwGVOx-2p0ef0ww7MqIt3wwZ0pfZY-1lpjBpeIGIvpQHTZ1o7R3HUulB9-lgcJFQvgZDPPWs3pzcBKHQVYFoBnZrG8GBZBuTycfTKrBGTLPBLxBlDFfmaCqx0fK48Fki9thb0FvsYN8MEoYiZ9NBUFH5xE'
  },
  {
    id: '3',
    name: 'Tacos (Pollo Asado)',
    description: 'Orden de tacos con delicioso pollo asado.',
    price: 15,
    category: 'Antojitos',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCbNLkxOUSDLo5qLw2RvRRXAa2LNebZcEGacQmsD0rVjRv4D4dkLIUTKzYol3LgV4et7c2vUC4BAUa7MyKEt2EtyHWab3uOP_jumphGE_k0ClsEPuhlYGAhXe4aBUf6vjbEV2N5zcbwViVDbRiuUF-U3gL481bVGHlig5BhzCoarJj3zh5ic0185v3DCqCqVHHdlVAZj8Bv_TWCEgcgT5i8ivLJpIgTCgeAkrLoPFQt1_7wcyeF078vUBF8_5-JvxUHLdgTYACI2Mk'
  },
  {
    id: '4',
    name: 'Chilaquiles',
    description: 'Chilaquiles tradicionales con el toque de La Wera.',
    price: 45,
    category: 'Antojitos',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDER-kP5XE8LM4LOMRK8oNZCRKxDux3vspN5DS5X0TsdycAY-L1SR4nLp0K-k_qUpq1RPAANdLpg54Dc0BgA9mwPtOsCRtgvqBr_k7-VfZ7gChxTh8OwN3m8N5Uuk9kfOzwoYwmJ_NHgZzlxdfPxXZ2zbmQ9o6O9Dd33Zzadub9gPNFioVNOgNVdSKNcjASju7gUOpboy-dJoHgsK6_OeZIGjW2FSPfbpoGnwoSzMJUdXOAOTlHKXBJ-EfF_SysnXhI2ovyVOvVvY4'
  },
  {
    id: '5',
    name: 'Uvas',
    description: 'Uvas frescas y dulces.',
    price: 35,
    category: 'Frutas',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBdfaY9CFeP1MD0jKQ4sJecZuXYP2OmY_VIzgRgAH9N5q2ON_AvA2CAm12rZtvbDs2-mzlobh3KBSs0hcH0CqbzAaCqqK3ZZYmqDttEi252bCKkPIyJ-4JkZ4OWONv58nnI-xRemIpoEQsp9Pjhxc-9iJxiCuqQUcsIrgAgNubvS_py7_B6IOEVuOAovfgqe5Kzahr-8EIaBpioNL6hdTuKw7XzILrmR5VmhwUM6lS0Dv5Hn4yKiO2Rs5XGd9Uz1aAlPRBjeu5Xq1M'
  },
  {
    id: '6',
    name: 'Manzanas',
    description: 'Manzanas rojas crujientes.',
    price: 30,
    category: 'Frutas',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC1otaQWnsJxfVEhycJC3hov2X91bz8kaz7O82-vlsUY_rkTAewmHCp0GgXgiY8gojBzsIkcHghxuvo6OIB_4FPQnOioi4-gz7ZE6zw3ycxyzBR3BXvZE4h2oN41MNW5i_F39jVjmTgSZ9h0iG8vFqdTB4o69wOyMCtTatV5vFsg5KU_XuW2ubGD5zw-78HcKZPVNsHezJ1NSNROgeZiDaYN4SBqVu4Sbs7TB9RJFlDzUWpEx-tJE36EH1DUpJx16JEOTJa7MXh4NI'
  },
  {
    id: '7',
    name: 'Fresas',
    description: 'Fresas jugosas y frescas.',
    price: 15,
    category: 'Frutas',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBykj6Qw7vHNbWYmgfd5rR3NZbS9Vy99wGSt_zM0Pe6YTaTv0O7B_BNUjdw_oOxYXuFxIGklSfD6JK3tzmRFNE7DWDj_ZbOGl1U3kqY7HWGXErJA0HXIDCu8Z13M_fMQva01J4VS73tckGZxqLCR-S8oSLSoAzWJEHTHNLWBYm0_KrNy1u9seo22RluOUqUZv00Z1pfOsw3VYYUffjMvUBVY2eqGOQMUtyvwbJEbbcUzh2Z18F9msyrljq6nhGHgLM4QlpxUzoB-tc'
  },
  {
    id: '8',
    name: 'Electrolit',
    description: 'Suero Electrolit hidratante.',
    price: 25,
    category: 'Bebidas',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDg6AaFuUrJbZGHuj3_TUdPoUa7cnEuDJPWvrmwasaFCpQQIN76d3UZoVGvdpInF2BbxpiJGgqh6IaXTo6dUjBunh93OugwX6kkZfUobfMQY14kRKRRqQTA6aNMlAqVqGxS1W8__rYBS3pawMQEdxOXagey2b8rw8uWKM3mr_YLapZZHOBMu93qH70kwaYuJGY-0Mhza3ILqwlinMu45oRXl6VDfAImzWme1zip8iL-b0k5avEvU8HbUUUZ2MGug5yx4k-_GDeaFDQ'
  },
  {
    id: '9',
    name: 'Agua Lt (Sabor)',
    description: 'Agua de sabor natural tamaño grande.',
    price: 17,
    category: 'Bebidas',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAZFajhX9sy53e7vqhod58QU4nbyHSBz_JpXs6AGC-pxiHXrRAlopKNUwh5GLuZKnnoLWvEBZCwBwJ9UhyxGWyTQ-RB-cNa_RZeSi9efLaziFqQaXFkHwbVTWGSbF2AELWeEhDteUN5rANE7A2frp4aFoWDiZh4r6s70w6xWKIY83GjXeqGn0kNbPmy-62jM6k-XSLkze8KjiJSIYixCIEitZ_PWBh40WCxyn3K6KQ-jwKxkVzv7tK_60tBlfcZDiGHo_tyRxSozNk'
  },
  {
    id: '9-2',
    name: 'Agua Lt (Natural)',
    description: 'Agua purificada tamaño grande.',
    price: 15,
    category: 'Bebidas',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAZFajhX9sy53e7vqhod58QU4nbyHSBz_JpXs6AGC-pxiHXrRAlopKNUwh5GLuZKnnoLWvEBZCwBwJ9UhyxGWyTQ-RB-cNa_RZeSi9efLaziFqQaXFkHwbVTWGSbF2AELWeEhDteUN5rANE7A2frp4aFoWDiZh4r6s70w6xWKIY83GjXeqGn0kNbPmy-62jM6k-XSLkze8KjiJSIYixCIEitZ_PWBh40WCxyn3K6KQ-jwKxkVzv7tK_60tBlfcZDiGHo_tyRxSozNk'
  },
  {
    id: '10',
    name: 'Agua ch. (Sabor)',
    description: 'Agua de sabor natural tamaño chico.',
    price: 13,
    category: 'Bebidas',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB3E2IYA552npT6Se9zMO9hwzaP_8VwDmzMOZoRZ-eGjWSw9UDMZwKF649oE7AUaIPPBsEWI3P8rCF5z5M2zGgrjNeV28zBzstSxfYEmnJcP4nQqnGr2uxjjei_hl1I6ZXGQz3hBJWMvmxXsppnjLU_uEcHyEQXOdR-5dZYmyHE5Su_l9znEAfZbYV9Wva34dUP4Sv4R0Vs-D04_y0MobXCsOJIJIUe-TNs9JrK5MLsi3ulIzGsasn6-cSBRB2FBaJiqMCLXPXhNkw'
  },
  {
    id: '10-2',
    name: 'Agua ch. (Natural)',
    description: 'Agua purificada tamaño chico.',
    price: 10,
    category: 'Bebidas',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB3E2IYA552npT6Se9zMO9hwzaP_8VwDmzMOZoRZ-eGjWSw9UDMZwKF649oE7AUaIPPBsEWI3P8rCF5z5M2zGgrjNeV28zBzstSxfYEmnJcP4nQqnGr2uxjjei_hl1I6ZXGQz3hBJWMvmxXsppnjLU_uEcHyEQXOdR-5dZYmyHE5Su_l9znEAfZbYV9Wva34dUP4Sv4R0Vs-D04_y0MobXCsOJIJIUe-TNs9JrK5MLsi3ulIzGsasn6-cSBRB2FBaJiqMCLXPXhNkw'
  }
];
